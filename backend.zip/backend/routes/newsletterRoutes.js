const express = require('express');
const router = express.Router();
const NewsletterEmail = require('../models/NewsletterEmail');
const nodemailer = require('nodemailer');

router.get('/emails', async (req, res) => {
  try {
    const emails = await NewsletterEmail.find();
    res.json(emails);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar emails.' });
  }
});

router.post('/send', async (req, res) => {
  const { message } = req.body;
  try {
    const emails = await NewsletterEmail.find();
    let sentCount = 0;

    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    for (const email of emails) {
      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: email.address,
        subject: 'Newsletter',
        text: message,
      });
      sentCount++;
    }

    res.json({ sentCount });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao enviar emails.' });
  }
});

module.exports = router;
