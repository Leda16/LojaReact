const mongoose = require('mongoose');

const NewsletterEmailSchema = new mongoose.Schema({
  address: { type: String, required: true },
});

module.exports = mongoose.model('NewsletterEmail', NewsletterEmailSchema);
